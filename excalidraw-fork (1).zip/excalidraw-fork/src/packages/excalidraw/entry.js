import "./publicPath";
import polyfill from "../../polyfill";

import "../../../public/fonts.css";

polyfill();
export * from "./index";
